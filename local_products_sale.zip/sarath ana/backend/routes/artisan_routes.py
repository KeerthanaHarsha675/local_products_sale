"""
=========================================================
HeritageHandcrafts - Artisan Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify
from flask import request

from services.artisan_service import (
    get_artisan_profile,
    update_artisan_profile,
    get_artisan_products,
    get_artisan_dashboard
)

# =========================================================
# Blueprint
# =========================================================
artisan_bp = Blueprint("artisan", __name__)


# =========================================================
# Get Artisan Profile
# GET /api/artisan/<artisan_id>
# =========================================================
@artisan_bp.route("/<int:artisan_id>", methods=["GET"])
def fetch_artisan_profile(artisan_id):

    artisan = get_artisan_profile(artisan_id)

    if not artisan:

        return jsonify({

            "success": False,

            "message": "Artisan not found."

        }), 404

    return jsonify({

        "id": artisan.id,

        "user_id": artisan.user_id,

        "profile_image": artisan.profile_image,

        "bio": artisan.bio,

        "years_of_experience": artisan.years_of_experience,

        "specialization": artisan.specialization,

        "district": artisan.district,

        "state": artisan.state,

        "address": artisan.address,

        "is_verified": artisan.is_verified,

        "website": artisan.website,

        "instagram": artisan.instagram,

        "facebook": artisan.facebook,

        "youtube": artisan.youtube

    })


# =========================================================
# Update Artisan Profile
# PUT /api/artisan/<artisan_id>
# =========================================================
@artisan_bp.route("/<int:artisan_id>", methods=["PUT"])
def edit_artisan_profile(artisan_id):

    data = request.get_json()

    result = update_artisan_profile(

        artisan_id,

        data

    )

    return jsonify(result)


# =========================================================
# Get Artisan Products
# GET /api/artisan/<artisan_id>/products
# =========================================================
@artisan_bp.route("/<int:artisan_id>/products", methods=["GET"])
def fetch_artisan_products(artisan_id):

    products = get_artisan_products(artisan_id)

    result = []

    for product in products:

        result.append({

            "id": product.id,

            "product_name": product.product_name,

            "price": product.price,

            "stock": product.stock,

            "status": product.status,

            "is_gi_product": product.is_gi_product

        })

    return jsonify(result)


# =========================================================
# Artisan Dashboard
# GET /api/artisan/<artisan_id>/dashboard
# =========================================================
@artisan_bp.route("/<int:artisan_id>/dashboard", methods=["GET"])
def artisan_dashboard(artisan_id):

    result = get_artisan_dashboard(

        artisan_id

    )

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/artisan/health
# =========================================================
@artisan_bp.route("/health", methods=["GET"])
def artisan_health():

    return jsonify({

        "success": True,

        "message": "Artisan API is running."

    })