"""
=========================================================
HeritageHandcrafts - Customer Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify
from flask import request

from services.customer_service import (
    get_customer_profile,
    update_customer_profile,
    get_customer_dashboard
)

# =========================================================
# Blueprint
# =========================================================
customer_bp = Blueprint("customer", __name__)


# =========================================================
# Get Customer Profile
# GET /api/customer/<customer_id>
# =========================================================
@customer_bp.route("/<int:customer_id>", methods=["GET"])
def fetch_customer_profile(customer_id):

    customer = get_customer_profile(customer_id)

    if not customer:

        return jsonify({

            "success": False,

            "message": "Customer not found."

        }), 404

    return jsonify({

        "id": customer.id,

        "user_id": customer.user_id,

        "phone": customer.phone,

        "profile_image": customer.profile_image,

        "date_of_birth": customer.date_of_birth,

        "gender": customer.gender,

        "address": customer.address,

        "city": customer.city,

        "district": customer.district,

        "state": customer.state,

        "pincode": customer.pincode

    })


# =========================================================
# Update Customer Profile
# PUT /api/customer/<customer_id>
# =========================================================
@customer_bp.route("/<int:customer_id>", methods=["PUT"])
def edit_customer_profile(customer_id):

    data = request.get_json()

    result = update_customer_profile(

        customer_id,

        data

    )

    return jsonify(result)


# =========================================================
# Customer Dashboard
# GET /api/customer/<customer_id>/dashboard
# =========================================================
@customer_bp.route("/<int:customer_id>/dashboard", methods=["GET"])
def customer_dashboard(customer_id):

    customer = get_customer_profile(customer_id)

    if not customer:

        return jsonify({

            "success": False,

            "message": "Customer not found."

        }), 404

    result = get_customer_dashboard(customer)

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/customer/health
# =========================================================
@customer_bp.route("/health", methods=["GET"])
def customer_health():

    return jsonify({

        "success": True,

        "message": "Customer API is running."

    })
