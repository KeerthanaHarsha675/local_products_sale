"""
=========================================================
HeritageHandcrafts - Admin Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify

from services.admin_service import (
    get_admin_dashboard,
    get_all_products,
    get_all_artisans,
    approve_product,
    reject_product
)

# =========================================================
# Blueprint
# =========================================================
admin_bp = Blueprint("admin", __name__)


# =========================================================
# Admin Dashboard
# GET /api/admin/dashboard
# =========================================================
@admin_bp.route("/dashboard", methods=["GET"])
def dashboard():

    result = get_admin_dashboard()

    return jsonify(result)


# =========================================================
# Get All Products
# GET /api/admin/products
# =========================================================
@admin_bp.route("/products", methods=["GET"])
def all_products():

    products = get_all_products()

    result = []

    for product in products:

        result.append({

            "id": product.id,

            "product_name": product.product_name,

            "artisan_id": product.artisan_id,

            "price": product.price,

            "status": product.status,

            "is_gi_product": product.is_gi_product

        })

    return jsonify(result)


# =========================================================
# Get All Artisans
# GET /api/admin/artisans
# =========================================================
@admin_bp.route("/artisans", methods=["GET"])
def all_artisans():

    artisans = get_all_artisans()

    result = []

    for artisan in artisans:

        result.append({

            "id": artisan.id,

            "user_id": artisan.user_id,

            "specialization": artisan.specialization,

            "district": artisan.district,

            "state": artisan.state,

            "is_verified": artisan.is_verified

        })

    return jsonify(result)


# =========================================================
# Approve Product
# PUT /api/admin/products/<product_id>/approve
# =========================================================
@admin_bp.route("/products/<int:product_id>/approve", methods=["PUT"])
def approve(product_id):

    result = approve_product(product_id)

    return jsonify(result)


# =========================================================
# Reject Product
# PUT /api/admin/products/<product_id>/reject
# =========================================================
@admin_bp.route("/products/<int:product_id>/reject", methods=["PUT"])
def reject(product_id):

    result = reject_product(product_id)

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/admin/health
# =========================================================
@admin_bp.route("/health", methods=["GET"])
def admin_health():

    return jsonify({

        "success": True,

        "message": "Admin API is running."

    })