"""
=========================================================
HeritageHandcrafts - Authentication Routes
=========================================================
"""

from flask import Blueprint, request, jsonify

from services.auth_service import (
    register_customer,
    register_artisan,
    login_user
)

# =========================================================
# Blueprint
# =========================================================
auth_bp = Blueprint("auth", __name__)


# =========================================================
# Customer Registration
# POST /api/auth/register/customer
# =========================================================
@auth_bp.route("/register/customer", methods=["POST"])
def customer_registration():

    data = request.get_json()

    result = register_customer(data)

    return jsonify(result)


# =========================================================
# Artisan Registration
# POST /api/auth/register/artisan
# =========================================================
@auth_bp.route("/register/artisan", methods=["POST"])
def artisan_registration():

    data = request.get_json()

    result = register_artisan(data)

    return jsonify(result)


# =========================================================
# Login
# POST /api/auth/login
# =========================================================
@auth_bp.route("/login", methods=["POST"])
def login():

    data = request.get_json()

    result = login_user(data)

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/auth
# =========================================================
@auth_bp.route("/", methods=["GET"])
def auth_home():

    return jsonify({
        "success": True,
        "message": "Authentication API is running."
    })