"""
=========================================================
HeritageHandcrafts - AI Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify
from flask import request

from services.ai_description import (
    generate_product_description
)

# =========================================================
# Blueprint
# =========================================================
ai_bp = Blueprint("ai", __name__)


# =========================================================
# Generate Product Description
# POST /api/ai/generate-description
# =========================================================
@ai_bp.route("/generate-description", methods=["POST"])
def generate_description():

    data = request.get_json()

    result = generate_product_description(data)

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/ai/
# =========================================================
@ai_bp.route("/", methods=["GET"])
def ai_home():

    return jsonify({

        "success": True,

        "message": "AI Service is running."

    })