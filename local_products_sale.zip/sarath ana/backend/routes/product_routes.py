"""
=========================================================
HeritageHandcrafts - Product Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify
from flask import request

from services.product_service import (
    add_product,
    get_all_products,
    get_product,
    delete_product,
    upload_product_images,
    upload_product_video
)
# =========================================================
# Blueprint
# =========================================================
product_bp = Blueprint("product", __name__)


# =========================================================
# Add Product
# POST /api/products/add
# =========================================================
@product_bp.route("/add", methods=["POST"])
def create_product():

    data = request.get_json()

    result = add_product(data)

    return jsonify(result)

# =========================================================
# Upload Product Images
# POST /api/products/<product_id>/images
# =========================================================
@product_bp.route("/<int:product_id>/images", methods=["POST"])
def upload_images(product_id):

    if "images" not in request.files:

        return jsonify({

            "success": False,

            "message": "No images uploaded."

        }), 400

    files = request.files.getlist("images")

    result = upload_product_images(

        product_id,

        files

    )

    return jsonify(result)

# =========================================================
# Upload Product Video
# POST /api/products/<product_id>/video
# =========================================================
@product_bp.route("/<int:product_id>/video", methods=["POST"])
def upload_video(product_id):

    if "video" not in request.files:

        return jsonify({

            "success": False,

            "message": "No video uploaded."

        }), 400

    file = request.files["video"]

    result = upload_product_video(

        product_id,

        file

    )

    return jsonify(result)
# =========================================================
# Get All Products
# GET /api/products/
# =========================================================
@product_bp.route("/", methods=["GET"])
def fetch_all_products():

    products = get_all_products()

    result = []

    for product in products:

        result.append({

            "id": product.id,

            "product_name": product.product_name,

            "category": product.category,

            "price": product.price,

            "stock": product.stock,

            "status": product.status,

            "is_gi_product": product.is_gi_product

        })

    return jsonify(result)


# =========================================================
# Get Product By ID
# GET /api/products/<product_id>
# =========================================================
@product_bp.route("/<int:product_id>", methods=["GET"])
def fetch_product(product_id):

    product = get_product(product_id)

    if not product:

        return jsonify({
            "success": False,
            "message": "Product not found."
        }), 404

    return jsonify({

        "id": product.id,

        "product_name": product.product_name,

        "category": product.category,

        "material": product.material,

        "price": product.price,

        "stock": product.stock,

        "description": product.ai_generated_description,

        "status": product.status,

        "is_gi_product": product.is_gi_product

    })


# =========================================================
# Delete Product
# DELETE /api/products/<product_id>
# =========================================================
@product_bp.route("/<int:product_id>", methods=["DELETE"])
def remove_product(product_id):

    result = delete_product(product_id)

    return jsonify(result)