"""
=========================================================
HeritageHandcrafts - Order Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify
from flask import request

from services.order_service import (
    create_order,
    get_all_orders,
    get_order,
    get_customer_orders,
    update_order_status,
    delete_order
)

# =========================================================
# Blueprint
# =========================================================
order_bp = Blueprint("order", __name__)


# =========================================================
# Create Order
# POST /api/orders/
# =========================================================
@order_bp.route("/", methods=["POST"])
def place_order():

    data = request.get_json()

    result = create_order(data)

    return jsonify(result)


# =========================================================
# Get All Orders
# GET /api/orders/
# =========================================================
@order_bp.route("/", methods=["GET"])
def fetch_all_orders():

    orders = get_all_orders()

    result = []

    for order in orders:

        result.append({

            "id": order.id,

            "order_number": order.order_number,

            "customer_id": order.customer_id,

            "grand_total": order.grand_total,

            "order_status": order.order_status,

            "created_at": order.created_at

        })

    return jsonify(result)


# =========================================================
# Get Order By ID
# GET /api/orders/<order_id>
# =========================================================
@order_bp.route("/<int:order_id>", methods=["GET"])
def fetch_order(order_id):

    order = get_order(order_id)

    if not order:

        return jsonify({

            "success": False,

            "message": "Order not found."

        }), 404

    return jsonify({

        "id": order.id,

        "order_number": order.order_number,

        "customer_id": order.customer_id,

        "total_amount": order.total_amount,

        "shipping_charge": order.shipping_charge,

        "tax_amount": order.tax_amount,

        "discount_amount": order.discount_amount,

        "grand_total": order.grand_total,

        "order_status": order.order_status,

        "customer_name": order.customer_name,

        "phone_number": order.phone_number,

        "email": order.email,

        "address": order.address,

        "city": order.city,

        "district": order.district,

        "state": order.state,

        "pincode": order.pincode,

        "courier_name": order.courier_name,

        "tracking_number": order.tracking_number

    })


# =========================================================
# Get Orders of a Customer
# GET /api/orders/customer/<customer_id>
# =========================================================
@order_bp.route("/customer/<int:customer_id>", methods=["GET"])
def fetch_customer_orders(customer_id):

    orders = get_customer_orders(customer_id)

    result = []

    for order in orders:

        result.append({

            "id": order.id,

            "order_number": order.order_number,

            "grand_total": order.grand_total,

            "order_status": order.order_status,

            "created_at": order.created_at

        })

    return jsonify(result)


# =========================================================
# Update Order Status
# PUT /api/orders/<order_id>/status
# =========================================================
@order_bp.route("/<int:order_id>/status", methods=["PUT"])
def change_order_status(order_id):

    data = request.get_json()

    result = update_order_status(

        order_id,

        data["status"]

    )

    return jsonify(result)


# =========================================================
# Delete Order
# DELETE /api/orders/<order_id>
# =========================================================
@order_bp.route("/<int:order_id>", methods=["DELETE"])
def remove_order(order_id):

    result = delete_order(order_id)

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/orders/health
# =========================================================
@order_bp.route("/health", methods=["GET"])
def order_health():

    return jsonify({

        "success": True,

        "message": "Order API is running."

    })