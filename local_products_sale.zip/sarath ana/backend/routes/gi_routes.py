"""
=========================================================
HeritageHandcrafts - GI Routes
=========================================================
"""

from flask import Blueprint
from flask import jsonify

from services.gi_service import (
    get_all_gi_tags,
    get_gi_tag,
    get_products_by_gi_tag
)

# =========================================================
# Blueprint
# =========================================================
gi_bp = Blueprint("gi", __name__)


# =========================================================
# Get All GI Tags
# GET /api/gi/
# =========================================================
@gi_bp.route("/", methods=["GET"])
def fetch_all_gi_tags():

    gi_tags = get_all_gi_tags()

    result = []

    for tag in gi_tags:

        result.append({

            "id": tag.id,

            "gi_name": tag.gi_name,

            "district": tag.district,

            "state": tag.state

        })

    return jsonify(result)


# =========================================================
# Get GI Tag By ID
# GET /api/gi/<id>
# =========================================================
@gi_bp.route("/<int:gi_tag_id>", methods=["GET"])
def fetch_gi_tag(gi_tag_id):

    tag = get_gi_tag(gi_tag_id)

    if not tag:

        return jsonify({

            "success": False,

            "message": "GI Tag not found."

        }), 404

    return jsonify({

        "id": tag.id,

        "gi_name": tag.gi_name,

        "district": tag.district,

        "state": tag.state,

        "description": tag.description

    })


# =========================================================
# Get Products By GI Tag
# GET /api/gi/<id>/products
# =========================================================
@gi_bp.route("/<int:gi_tag_id>/products", methods=["GET"])
def fetch_products_by_gi_tag(gi_tag_id):

    products = get_products_by_gi_tag(gi_tag_id)

    result = []

    for product in products:

        result.append({

            "id": product.id,

            "product_name": product.product_name,

            "price": product.price,

            "stock": product.stock,

            "is_gi_product": product.is_gi_product

        })

    return jsonify(result)


# =========================================================
# Health Check
# GET /api/gi/health
# =========================================================
@gi_bp.route("/health", methods=["GET"])
def gi_health():

    return jsonify({

        "success": True,

        "message": "GI API is running."

    })