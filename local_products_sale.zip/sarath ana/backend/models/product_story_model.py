"""
=========================================================
HeritageHandcrafts - Product Story Model
=========================================================
"""

from datetime import datetime
from models import db


class ProductStory(db.Model):

    __tablename__ = "product_stories"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Product Reference
    # -------------------------------------------------
    product_id = db.Column(
        db.Integer,
        db.ForeignKey("products.id"),
        nullable=False,
        unique=True
    )

    # -------------------------------------------------
    # Story Details
    # -------------------------------------------------
    title = db.Column(
        db.String(200),
        nullable=False
    )

    heritage_story = db.Column(
        db.Text,
        nullable=False
    )

    cultural_significance = db.Column(
        db.Text
    )

    crafting_process = db.Column(
        db.Text
    )

    artist_story = db.Column(
        db.Text
    )

    region_history = db.Column(
        db.Text
    )

    # -------------------------------------------------
    # AI Generated Story
    # -------------------------------------------------
    ai_generated_story = db.Column(
        db.Text
    )

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationship
    # -------------------------------------------------
    product = db.relationship(
        "Product",
        backref="story",
        lazy=True
    )

    def __repr__(self):
        return f"<ProductStory {self.title}>"