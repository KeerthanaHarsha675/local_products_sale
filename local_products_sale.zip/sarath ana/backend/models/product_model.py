"""
=========================================================
HeritageHandcrafts - Product Model
=========================================================
"""

from datetime import datetime
from models import db


class Product(db.Model):

    __tablename__ = "products"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    artisan_id = db.Column(
        db.Integer,
        db.ForeignKey("artisans.id"),
        nullable=False
    )

    gi_tag_id = db.Column(
        db.Integer,
        db.ForeignKey("gi_tags.id"),
        nullable=True
    )

    # -------------------------------------------------
    # Basic Product Details
    # -------------------------------------------------
    product_name = db.Column(
        db.String(200),
        nullable=False
    )

    category = db.Column(
        db.String(100),
        nullable=False
    )

    material = db.Column(
        db.String(150)
    )

    dimensions = db.Column(
        db.String(100)
    )

    weight = db.Column(
        db.String(50)
    )

    color = db.Column(
        db.String(100)
    )

    quantity_available = db.Column(
        db.Integer,
        default=1
    )

    sku = db.Column(
        db.String(100),
        unique=True
    )

    # -------------------------------------------------
    # Description
    # -------------------------------------------------
    short_description = db.Column(db.Text)

    ai_generated_description = db.Column(db.Text)

    # -------------------------------------------------
    # Pricing
    # -------------------------------------------------
    price = db.Column(
        db.Float,
        nullable=False
    )

    discount_price = db.Column(
        db.Float
    )

    # Future AI Pricing
    ai_suggested_price = db.Column(
        db.Float
    )

    # -------------------------------------------------
    # Inventory
    # -------------------------------------------------
    stock = db.Column(
        db.Integer,
        default=0
    )

    # -------------------------------------------------
    # Product Status
    # -------------------------------------------------
    status = db.Column(
        db.String(30),
        default="Pending"
    )

    # Pending
    # Approved
    # Rejected
    # Out of Stock

    # -------------------------------------------------
    # GI Verification
    # -------------------------------------------------
    is_gi_product = db.Column(
        db.Boolean,
        default=False
    )

    gi_certificate = db.Column(
        db.String(255)
    )

    gi_verification_status = db.Column(
        db.String(30),
        default="Pending"
    )

    # -------------------------------------------------
    # Video
    # -------------------------------------------------
    youtube_url = db.Column(
        db.String(255)
    )

    product_video = db.Column(
        db.String(255)
    )

    # -------------------------------------------------
    # Ratings
    # -------------------------------------------------
    average_rating = db.Column(
        db.Float,
        default=0.0
    )

    total_reviews = db.Column(
        db.Integer,
        default=0
    )

    # -------------------------------------------------
    # Timestamps
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    artisan = db.relationship(
        "Artisan",
        backref="products",
        lazy=True
    )

    gi_tag = db.relationship(
        "GITag",
        backref="products",
        lazy=True
    )

    def __repr__(self):
        return f"<Product {self.product_name}>"