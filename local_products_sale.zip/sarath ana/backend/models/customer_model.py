"""
=========================================================
HeritageHandcrafts - Customer Model
=========================================================
"""

from datetime import datetime
from models import db


class Customer(db.Model):

    __tablename__ = "customers"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(
        db.Integer,
        primary_key=True
    )

    # -------------------------------------------------
    # Linked User
    # -------------------------------------------------
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False,
        unique=True
    )

    # -------------------------------------------------
    # Customer Details
    # -------------------------------------------------
    phone = db.Column(
        db.String(20)
    )

    profile_image = db.Column(
        db.String(255)
    )

    date_of_birth = db.Column(
        db.Date
    )

    gender = db.Column(
        db.String(20)
    )

    # -------------------------------------------------
    # Address
    # -------------------------------------------------
    address = db.Column(
        db.Text
    )

    city = db.Column(
        db.String(100)
    )

    district = db.Column(
        db.String(100)
    )

    state = db.Column(
        db.String(100),
        default="Tamil Nadu"
    )

    pincode = db.Column(
        db.String(10)
    )

    # -------------------------------------------------
    # Date & Time
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationship
    # -------------------------------------------------
    user = db.relationship(
        "User",
        backref="customer_profile",
        lazy=True
    )

    def __repr__(self):

        return f"<Customer {self.id}>"