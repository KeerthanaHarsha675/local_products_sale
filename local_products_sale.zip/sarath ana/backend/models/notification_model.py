"""
=========================================================
HeritageHandcrafts - Notification Model
=========================================================
"""

from datetime import datetime
from models import db


class Notification(db.Model):

    __tablename__ = "notifications"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # User Reference
    # -------------------------------------------------
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Notification Details
    # -------------------------------------------------
    title = db.Column(
        db.String(200),
        nullable=False
    )

    message = db.Column(
        db.Text,
        nullable=False
    )

    notification_type = db.Column(
        db.String(50),
        nullable=False
    )

    # Examples:
    # Order
    # Payment
    # Product
    # GI Verification
    # Admin
    # Promotion

    # -------------------------------------------------
    # Read Status
    # -------------------------------------------------
    is_read = db.Column(
        db.Boolean,
        default=False
    )

    # -------------------------------------------------
    # Optional Reference
    # -------------------------------------------------
    reference_id = db.Column(
        db.Integer
    )

    reference_type = db.Column(
        db.String(50)
    )

    # Examples:
    # Product
    # Order
    # Payment
    # GI

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationship
    # -------------------------------------------------
    user = db.relationship(
        "User",
        backref="notifications",
        lazy=True
    )

    def __repr__(self):
        return f"<Notification {self.id}>"