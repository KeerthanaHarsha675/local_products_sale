"""
=========================================================
HeritageHandcrafts - Order Item Model
=========================================================
"""

from datetime import datetime
from models import db


class OrderItem(db.Model):

    __tablename__ = "order_items"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    order_id = db.Column(
        db.Integer,
        db.ForeignKey("orders.id"),
        nullable=False
    )

    product_id = db.Column(
        db.Integer,
        db.ForeignKey("products.id"),
        nullable=False
    )

    artisan_id = db.Column(
        db.Integer,
        db.ForeignKey("artisans.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Product Details
    # -------------------------------------------------
    product_name = db.Column(
        db.String(200),
        nullable=False
    )

    quantity = db.Column(
        db.Integer,
        nullable=False
    )

    unit_price = db.Column(
        db.Float,
        nullable=False
    )

    total_price = db.Column(
        db.Float,
        nullable=False
    )

    # -------------------------------------------------
    # Order Status (Per Product)
    # -------------------------------------------------
    item_status = db.Column(
        db.String(30),
        default="Pending"
    )

    # Pending
    # Confirmed
    # Packed
    # Shipped
    # Delivered
    # Cancelled

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    order = db.relationship(
        "Order",
        backref="order_items",
        lazy=True
    )

    product = db.relationship(
        "Product",
        backref="order_items",
        lazy=True
    )

    artisan = db.relationship(
        "Artisan",
        backref="order_items",
        lazy=True
    )

    def __repr__(self):
        return f"<OrderItem {self.id}>"