"""
=========================================================
HeritageHandcrafts - GI Tag Model
=========================================================
"""

from datetime import datetime
from models import db


class GITag(db.Model):

    __tablename__ = "gi_tags"

    # Primary Key
    id = db.Column(db.Integer, primary_key=True)

    # Region
    region = db.Column(
        db.String(100),
        nullable=False
    )

    # GI Product Name
    gi_product_name = db.Column(
        db.String(150),
        nullable=False
    )

    # Description
    description = db.Column(db.Text)

    # Active Status
    is_active = db.Column(
        db.Boolean,
        default=True
    )

    # Date & Time
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    def __repr__(self):
        return f"<GITag {self.gi_product_name}>"