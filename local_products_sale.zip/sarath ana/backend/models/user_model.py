"""
=========================================================
HeritageHandcrafts - User Model
=========================================================

This model stores all users in the system.

User Roles:
1. Admin
2. Artisan
3. Customer

Every person who logs into the application
must have an account in this table.
"""

from datetime import datetime
from models import db


class User(db.Model):

    __tablename__ = "users"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Personal Details
    # -------------------------------------------------
    full_name = db.Column(db.String(100), nullable=False)

    email = db.Column(
        db.String(120),
        unique=True,
        nullable=False
    )

    phone_number = db.Column(
        db.String(15),
        unique=True,
        nullable=False
    )

    password = db.Column(
        db.String(255),
        nullable=False
    )

    # -------------------------------------------------
    # User Role
    # -------------------------------------------------
    role = db.Column(
        db.String(20),
        nullable=False
    )

    # Values:
    # Admin
    # Artisan
    # Customer

    # -------------------------------------------------
    # Account Status
    # -------------------------------------------------
    is_verified = db.Column(
        db.Boolean,
        default=False
    )

    is_active = db.Column(
        db.Boolean,
        default=True
    )

    # -------------------------------------------------
    # Date & Time
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # String Representation
    # -------------------------------------------------
    def __repr__(self):
        return f"<User {self.full_name}>"