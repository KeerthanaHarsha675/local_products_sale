"""
=========================================================
HeritageHandcrafts - Order Model
=========================================================
"""

from datetime import datetime
from models import db


class Order(db.Model):

    __tablename__ = "orders"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Customer
    # -------------------------------------------------
    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Order Information
    # -------------------------------------------------
    order_number = db.Column(
        db.String(50),
        unique=True,
        nullable=False
    )

    total_amount = db.Column(
        db.Float,
        nullable=False
    )

    shipping_charge = db.Column(
        db.Float,
        default=0.0
    )

    tax_amount = db.Column(
        db.Float,
        default=0.0
    )

    discount_amount = db.Column(
        db.Float,
        default=0.0
    )

    grand_total = db.Column(
        db.Float,
        nullable=False
    )

    # -------------------------------------------------
    # Order Status
    # -------------------------------------------------
    order_status = db.Column(
        db.String(30),
        default="Pending"
    )

    # Pending
    # Confirmed
    # Packed
    # Shipped
    # Delivered
    # Cancelled

    # -------------------------------------------------
    # Shipping Details
    # -------------------------------------------------
    customer_name = db.Column(db.String(150))

    phone_number = db.Column(db.String(15))

    email = db.Column(db.String(120))

    address = db.Column(db.Text)

    city = db.Column(db.String(100))

    district = db.Column(db.String(100))

    state = db.Column(db.String(100))

    pincode = db.Column(db.String(10))

    # -------------------------------------------------
    # Logistics
    # -------------------------------------------------
    courier_name = db.Column(db.String(100))

    tracking_number = db.Column(db.String(100))

    expected_delivery = db.Column(db.Date)

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationship
    # -------------------------------------------------
    customer = db.relationship(
        "User",
        backref="orders",
        lazy=True
    )

    def __repr__(self):
        return f"<Order {self.order_number}>"