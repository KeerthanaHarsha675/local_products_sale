"""
=========================================================
HeritageHandcrafts - Payment Model
=========================================================
"""

from datetime import datetime
from models import db


class Payment(db.Model):

    __tablename__ = "payments"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Order Reference
    # -------------------------------------------------
    order_id = db.Column(
        db.Integer,
        db.ForeignKey("orders.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Payment Information
    # -------------------------------------------------
    payment_method = db.Column(
        db.String(50),
        nullable=False
    )

    # Razorpay
    # Stripe
    # UPI
    # Card
    # Net Banking
    # COD

    payment_gateway = db.Column(
        db.String(50)
    )

    transaction_id = db.Column(
        db.String(150),
        unique=True
    )

    gateway_order_id = db.Column(
        db.String(150)
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    currency = db.Column(
        db.String(10),
        default="INR"
    )

    # -------------------------------------------------
    # Payment Status
    # -------------------------------------------------
    payment_status = db.Column(
        db.String(30),
        default="Pending"
    )

    # Pending
    # Paid
    # Failed
    # Refunded
    # Partially Refunded

    # -------------------------------------------------
    # Refund Details
    # -------------------------------------------------
    refund_amount = db.Column(
        db.Float,
        default=0.0
    )

    refund_transaction_id = db.Column(
        db.String(150)
    )

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationship
    # -------------------------------------------------
    order = db.relationship(
        "Order",
        backref="payment",
        lazy=True
    )

    def __repr__(self):
        return f"<Payment {self.transaction_id}>"