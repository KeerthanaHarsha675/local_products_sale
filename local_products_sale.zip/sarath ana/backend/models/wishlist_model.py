"""
=========================================================
HeritageHandcrafts - Wishlist Model
=========================================================
"""

from datetime import datetime
from models import db


class Wishlist(db.Model):

    __tablename__ = "wishlists"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    product_id = db.Column(
        db.Integer,
        db.ForeignKey("products.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    customer = db.relationship(
        "User",
        backref="wishlist_items",
        lazy=True
    )

    product = db.relationship(
        "Product",
        backref="wishlist_items",
        lazy=True
    )

    # -------------------------------------------------
    # Prevent Duplicate Wishlist Entries
    # -------------------------------------------------
    __table_args__ = (
        db.UniqueConstraint(
            "customer_id",
            "product_id",
            name="unique_customer_product"
        ),
    )

    def __repr__(self):
        return f"<Wishlist {self.id}>"