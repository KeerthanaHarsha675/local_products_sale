"""
=========================================================
HeritageHandcrafts - Review Model
=========================================================
"""

from datetime import datetime
from models import db


class Review(db.Model):

    __tablename__ = "reviews"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    product_id = db.Column(
        db.Integer,
        db.ForeignKey("products.id"),
        nullable=False
    )

    customer_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Review Details
    # -------------------------------------------------
    rating = db.Column(
        db.Integer,
        nullable=False
    )

    review_title = db.Column(
        db.String(150)
    )

    review_text = db.Column(
        db.Text
    )

    # -------------------------------------------------
    # Status
    # -------------------------------------------------
    is_approved = db.Column(
        db.Boolean,
        default=True
    )

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationships
    # -------------------------------------------------
    product = db.relationship(
        "Product",
        backref="reviews",
        lazy=True
    )

    customer = db.relationship(
        "User",
        backref="reviews",
        lazy=True
    )

    def __repr__(self):
        return f"<Review {self.id}>"