"""
=========================================================
HeritageHandcrafts - Database Initialization
=========================================================

This file initializes the SQLAlchemy database instance.

Every model in the project imports 'db' from here.

Example:
from models import db

Responsibilities:
- Initialize SQLAlchemy
- Provide a common database object for all models
"""

from flask_sqlalchemy import SQLAlchemy
from .customer_model import Customer

# Create SQLAlchemy object
db = SQLAlchemy()