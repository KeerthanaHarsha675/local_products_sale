"""
=========================================================
HeritageHandcrafts - Product Image Model
=========================================================
"""

from datetime import datetime
from models import db


class ProductImage(db.Model):

    __tablename__ = "product_images"

    # -------------------------------------------------
    # Primary Key
    # -------------------------------------------------
    id = db.Column(db.Integer, primary_key=True)

    # -------------------------------------------------
    # Product Reference
    # -------------------------------------------------
    product_id = db.Column(
        db.Integer,
        db.ForeignKey("products.id"),
        nullable=False
    )

    # -------------------------------------------------
    # Image Details
    # -------------------------------------------------
    image_path = db.Column(
        db.String(255),
        nullable=False
    )

    image_title = db.Column(
        db.String(150)
    )

    # -------------------------------------------------
    # Primary Image
    # -------------------------------------------------
    is_primary = db.Column(
        db.Boolean,
        default=False
    )

    # -------------------------------------------------
    # Image Display Order
    # -------------------------------------------------
    display_order = db.Column(
        db.Integer,
        default=1
    )

    # -------------------------------------------------
    # Status
    # -------------------------------------------------
    is_active = db.Column(
        db.Boolean,
        default=True
    )

    # -------------------------------------------------
    # Timestamp
    # -------------------------------------------------
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    # -------------------------------------------------
    # Relationship
    # -------------------------------------------------
    product = db.relationship(
        "Product",
        backref="images",
        lazy=True
    )

    def __repr__(self):
        return f"<ProductImage {self.id}>"