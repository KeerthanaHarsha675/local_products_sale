"""
=========================================================
HeritageHandcrafts - Artisan Model
=========================================================
"""

from datetime import datetime
from models import db


class Artisan(db.Model):

    __tablename__ = "artisans"

    # Primary Key
    id = db.Column(db.Integer, primary_key=True)

    # Linked User
    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False,
        unique=True
    )

    # Profile Details
    profile_image = db.Column(db.String(255))

    bio = db.Column(db.Text)

    years_of_experience = db.Column(db.Integer)

    specialization = db.Column(db.String(150))

    district = db.Column(db.String(100))

    state = db.Column(db.String(100), default="Tamil Nadu")

    address = db.Column(db.Text)

    # Verification
    is_verified = db.Column(db.Boolean, default=False)

    # Social Links
    website = db.Column(db.String(255))

    instagram = db.Column(db.String(255))

    facebook = db.Column(db.String(255))

    youtube = db.Column(db.String(255))

    # Future Use
    bank_account_name = db.Column(db.String(150))

    bank_account_number = db.Column(db.String(100))

    ifsc_code = db.Column(db.String(30))

    upi_id = db.Column(db.String(100))

    # Date & Time
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # Relationship
    user = db.relationship(
        "User",
        backref="artisan_profile",
        lazy=True
    )

    def __repr__(self):
        return f"<Artisan {self.id}>"