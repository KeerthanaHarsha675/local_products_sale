"""
=========================================================
HeritageHandcrafts - Authentication Service
=========================================================
"""

from models import db

from models.user_model import User
from models.artisan_model import Artisan

from services.password_service import (
    hash_password,
    verify_password
)

from services.jwt_service import generate_token


# =========================================================
# Register Customer
# =========================================================
def register_customer(data):

    # Check existing email
    existing_email = User.query.filter_by(
        email=data["email"]
    ).first()

    if existing_email:
        return {
            "success": False,
            "message": "Email already registered."
        }

    # Check existing phone
    existing_phone = User.query.filter_by(
        phone_number=data["phone_number"]
    ).first()

    if existing_phone:
        return {
            "success": False,
            "message": "Phone number already registered."
        }

    # Create User
    customer = User(
        full_name=data["full_name"],
        email=data["email"],
        phone_number=data["phone_number"],
        password=hash_password(data["password"]),
        role="Customer"
    )

    db.session.add(customer)
    db.session.commit()

    return {
        "success": True,
        "message": "Customer registered successfully."
    }


# =========================================================
# Register Artisan
# =========================================================
def register_artisan(data):

    # Check Email
    existing_email = User.query.filter_by(
        email=data["email"]
    ).first()

    if existing_email:
        return {
            "success": False,
            "message": "Email already registered."
        }

    # Check Phone
    existing_phone = User.query.filter_by(
        phone_number=data["phone_number"]
    ).first()

    if existing_phone:
        return {
            "success": False,
            "message": "Phone number already registered."
        }

    # Create User
    artisan_user = User(
        full_name=data["full_name"],
        email=data["email"],
        phone_number=data["phone_number"],
        password=hash_password(data["password"]),
        role="Artisan"
    )

    db.session.add(artisan_user)
    db.session.commit()

    # Create Artisan Profile
    artisan_profile = Artisan(
        user_id=artisan_user.id,
        district=data.get("district"),
        specialization=data.get("specialization")
    )

    db.session.add(artisan_profile)
    db.session.commit()

    return {
        "success": True,
        "message": "Artisan registered successfully."
    }


# =========================================================
# Login
# =========================================================
def login_user(data):

    user = User.query.filter_by(
        email=data["email"]
    ).first()

    if not user:
        return {
            "success": False,
            "message": "Invalid email or password."
        }

    if not verify_password(
        user.password,
        data["password"]
    ):
        return {
            "success": False,
            "message": "Invalid email or password."
        }

    token = generate_token(
        user.id,
        user.role
    )

    return {
        "success": True,
        "message": "Login successful.",
        "token": token,
        "user": {
            "id": user.id,
            "name": user.full_name,
            "email": user.email,
            "role": user.role
        }
    }