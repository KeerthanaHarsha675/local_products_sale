"""
=========================================================
HeritageHandcrafts - Artisan Service
=========================================================
"""

from models import db

from models.artisan_model import Artisan
from models.product_model import Product


# =========================================================
# Get Artisan Profile
# =========================================================
def get_artisan_profile(artisan_id):

    artisan = Artisan.query.get(artisan_id)

    return artisan


# =========================================================
# Update Artisan Profile
# =========================================================
def update_artisan_profile(artisan_id, data):

    artisan = Artisan.query.get(artisan_id)

    if not artisan:

        return {
            "success": False,
            "message": "Artisan not found."
        }

    artisan.specialization = data.get(
        "specialization",
        artisan.specialization
    )

    artisan.bio = data.get(
        "bio",
        artisan.bio
    )

    artisan.district = data.get(
        "district",
        artisan.district
    )

    #artisan.region = data.get(
     #   "region",
      #  artisan.region
    #)

    artisan.profile_image = data.get(
        "profile_image",
        artisan.profile_image
    )

    db.session.commit()

    return {
        "success": True,
        "message": "Artisan profile updated successfully."
    }


# =========================================================
# Get Artisan Products
# =========================================================
def get_artisan_products(artisan_id):

    products = Product.query.filter_by(
        artisan_id=artisan_id
    ).all()

    return products


# =========================================================
# Get Artisan Dashboard
# =========================================================
def get_artisan_dashboard(artisan_id):

    total_products = Product.query.filter_by(
        artisan_id=artisan_id
    ).count()

    active_products = Product.query.filter_by(
        artisan_id=artisan_id,
        status="Approved"
    ).count()

    pending_products = Product.query.filter_by(
        artisan_id=artisan_id,
        status="Pending"
    ).count()

    return {

        "total_products": total_products,

        "approved_products": active_products,

        "pending_products": pending_products

    }