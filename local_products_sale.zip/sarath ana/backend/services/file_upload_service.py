"""
=========================================================
HeritageHandcrafts - File Upload Service
=========================================================
"""

import os
import uuid

from werkzeug.utils import secure_filename

from config import Config


# =========================================================
# Check Allowed Image
# =========================================================
def allowed_image(filename):

    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower()
        in Config.ALLOWED_IMAGE_EXTENSIONS
    )


# =========================================================
# Check Allowed Video
# =========================================================
def allowed_video(filename):

    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower()
        in Config.ALLOWED_VIDEO_EXTENSIONS
    )


# =========================================================
# Save Image
# =========================================================
def save_image(file, upload_folder):

    if file is None:
        return None

    if not allowed_image(file.filename):
        return None

    extension = file.filename.rsplit(".", 1)[1].lower()

    filename = f"{uuid.uuid4()}.{extension}"

    filename = secure_filename(filename)

    filepath = os.path.join(upload_folder, filename)

    file.save(filepath)

    return filename


# =========================================================
# Save Video
# =========================================================
def save_video(file, upload_folder):

    if file is None:
        return None

    if not allowed_video(file.filename):
        return None

    extension = file.filename.rsplit(".", 1)[1].lower()

    filename = f"{uuid.uuid4()}.{extension}"

    filename = secure_filename(filename)

    filepath = os.path.join(upload_folder, filename)

    file.save(filepath)

    return filename