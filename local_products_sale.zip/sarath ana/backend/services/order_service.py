"""
=========================================================
HeritageHandcrafts - Order Service
=========================================================
"""

import uuid

from models import db

from models.order_model import Order


# =========================================================
# Generate Order Number
# =========================================================
def generate_order_number():

    return "ORD-" + str(uuid.uuid4())[:8].upper()


# =========================================================
# Create Order
# =========================================================
def create_order(data):

    order = Order(

        customer_id=data["customer_id"],

        order_number=generate_order_number(),

        total_amount=data["total_amount"],

        shipping_charge=data.get("shipping_charge", 0),

        tax_amount=data.get("tax_amount", 0),

        discount_amount=data.get("discount_amount", 0),

        grand_total=data["grand_total"],

        customer_name=data["customer_name"],

        phone_number=data["phone_number"],

        email=data["email"],

        address=data["address"],

        city=data["city"],

        district=data["district"],

        state=data["state"],

        pincode=data["pincode"]

    )

    db.session.add(order)

    db.session.commit()

    return {

        "success": True,

        "message": "Order placed successfully.",

        "order_id": order.id,

        "order_number": order.order_number

    }


# =========================================================
# Get All Orders
# =========================================================
def get_all_orders():

    return Order.query.all()


# =========================================================
# Get Order By ID
# =========================================================
def get_order(order_id):

    return Order.query.get(order_id)


# =========================================================
# Get Customer Orders
# =========================================================
def get_customer_orders(customer_id):

    return Order.query.filter_by(

        customer_id=customer_id

    ).all()


# =========================================================
# Update Order Status
# =========================================================
def update_order_status(order_id, status):

    order = Order.query.get(order_id)

    if not order:

        return {

            "success": False,

            "message": "Order not found."

        }

    order.order_status = status

    db.session.commit()

    return {

        "success": True,

        "message": "Order status updated successfully."

    }


# =========================================================
# Delete Order
# =========================================================
def delete_order(order_id):

    order = Order.query.get(order_id)

    if not order:

        return {

            "success": False,

            "message": "Order not found."

        }

    db.session.delete(order)

    db.session.commit()

    return {

        "success": True,

        "message": "Order deleted successfully."

    }