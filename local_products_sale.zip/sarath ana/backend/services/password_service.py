"""
=========================================================
HeritageHandcrafts - Password Service
=========================================================
"""

from werkzeug.security import generate_password_hash
from werkzeug.security import check_password_hash


def hash_password(password):
    """
    Convert plain password into hashed password.
    """
    return generate_password_hash(password)


def verify_password(hashed_password, password):
    """
    Verify entered password with stored hashed password.
    """
    return check_password_hash(hashed_password, password)