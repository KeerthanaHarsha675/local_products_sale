"""
=========================================================
HeritageHandcrafts - JWT Service
=========================================================
"""

from flask_jwt_extended import (
    create_access_token,
    decode_token
)


def generate_token(user_id, role):
    """
    Generate JWT Access Token
    """

    additional_claims = {
        "role": role
    }

    token = create_access_token(
        identity=user_id,
        additional_claims=additional_claims
    )

    return token


def verify_token(token):
    """
    Decode JWT Token
    """

    return decode_token(token)