"""
=========================================================
HeritageHandcrafts - Customer Service
=========================================================
"""

from models import db

from models.customer_model import Customer


# =========================================================
# Get Customer Profile
# =========================================================
def get_customer_profile(customer_id):

    customer = Customer.query.get(customer_id)

    return customer


# =========================================================
# Update Customer Profile
# =========================================================
def update_customer_profile(customer_id, data):

    customer = Customer.query.get(customer_id)

    if not customer:

        return {

            "success": False,

            "message": "Customer not found."

        }

    customer.phone = data.get(

        "phone",

        customer.phone

    )

    customer.address = data.get(

        "address",

        customer.address

    )

    customer.city = data.get(

        "city",

        customer.city

    )

    customer.state = data.get(

        "state",

        customer.state

    )

    customer.pincode = data.get(

        "pincode",

        customer.pincode

    )

    db.session.commit()

    return {

        "success": True,

        "message": "Customer profile updated successfully."

    }


# =========================================================
# Customer Dashboard
# =========================================================
def get_customer_dashboard(customer):

    return {

        "customer_id": customer.id,

        "message": "Customer dashboard loaded successfully."

    }