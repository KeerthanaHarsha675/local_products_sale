"""
=========================================================
HeritageHandcrafts - Product Service
=========================================================
"""

from models import db

from models.product_model import Product
from models.product_image_model import ProductImage
from models.product_story_model import ProductStory
from config import Config

from services.file_upload_service import (
    save_image,
    save_video
)

# =========================================================
# Add Product
# =========================================================
def add_product(data):

    product = Product(

        artisan_id=data["artisan_id"],

        gi_tag_id=data.get("gi_tag_id"),

        product_name=data["product_name"],

        category=data["category"],

        material=data.get("material"),

        dimensions=data.get("dimensions"),

        weight=data.get("weight"),

        color=data.get("color"),

        quantity_available=data.get("quantity_available", 1),

        sku=data.get("sku"),

        short_description=data.get("short_description"),

        ai_generated_description=data.get("ai_generated_description"),

        price=data["price"],

        discount_price=data.get("discount_price"),

        stock=data.get("stock", 0),

        is_gi_product=data.get("is_gi_product", False),

        youtube_url=data.get("youtube_url")
    )

    db.session.add(product)
    db.session.commit()

    return {
        "success": True,
        "message": "Product added successfully.",
        "product_id": product.id
    }
# =========================================================
# Upload Product Images
# =========================================================
def upload_product_images(product_id, files):

    uploaded_images = []

    for file in files:

        filename = save_image(
            file,
            Config.PRODUCT_UPLOAD_FOLDER
        )

        if filename:

            image = ProductImage(

                product_id=product_id,

                image_url=filename
            )

            db.session.add(image)

            uploaded_images.append(filename)

    db.session.commit()

    return {

        "success": True,

        "message": "Images uploaded successfully.",

        "images": uploaded_images

    }

# =========================================================
# Upload Product Video
# =========================================================
def upload_product_video(product_id, file):

    product = Product.query.get(product_id)

    if not product:

        return {

            "success": False,

            "message": "Product not found."

        }

    filename = save_video(

        file,

        Config.PRODUCT_UPLOAD_FOLDER

    )

    if filename:

        product.product_video = filename

        db.session.commit()

    return {

        "success": True,

        "message": "Video uploaded successfully.",

        "video": filename

    }
# =========================================================
# Get All Products
# =========================================================
def get_all_products():

    products = Product.query.all()

    return products


# =========================================================
# Get Product By ID
# =========================================================
def get_product(product_id):

    return Product.query.get(product_id)


# =========================================================
# Delete Product
# =========================================================
def delete_product(product_id):

    product = Product.query.get(product_id)

    if not product:
        return {
            "success": False,
            "message": "Product not found."
        }

    db.session.delete(product)
    db.session.commit()

    return {
        "success": True,
        "message": "Product deleted successfully."
    }