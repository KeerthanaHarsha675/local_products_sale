"""
=========================================================
HeritageHandcrafts - AI Description Service
=========================================================

Generates AI-powered product descriptions
based on artisan input.
=========================================================
"""


def generate_product_description(data):
    """
    Generate an AI-style product description.

    NOTE:
    This is currently a placeholder implementation.
    Later, this function can be connected to
    OpenAI, Gemini, Claude, or any LLM API.
    """

    product_name = data.get("product_name", "")
    category = data.get("category", "")
    material = data.get("material", "")
    region = data.get("region", "")
    crafting_process = data.get("crafting_process", "")
    cultural_significance = data.get(
        "cultural_significance",
        ""
    )

    description = f"""
{product_name} is a handcrafted {category.lower()} created by skilled artisans from {region}.

Made using premium {material.lower()}, this handcrafted product reflects traditional craftsmanship and attention to detail.

Crafting Process:
{crafting_process}

Cultural Significance:
{cultural_significance}

Every handcrafted piece is unique, preserving the heritage and artistic traditions of the region while supporting local artisans.
"""

    return {
        "success": True,
        "description": description.strip()
    }