"""
=========================================================
HeritageHandcrafts - GI Service
=========================================================
"""

from models.gi_model import GITag
from models.product_model import Product


# =========================================================
# Get All GI Tags
# =========================================================
def get_all_gi_tags():

    gi_tags = GITag.query.all()

    return gi_tags


# =========================================================
# Get GI Tag By ID
# =========================================================
def get_gi_tag(gi_tag_id):

    return GITag.query.get(gi_tag_id)


# =========================================================
# Get Products By GI Tag
# =========================================================
def get_products_by_gi_tag(gi_tag_id):

    products = Product.query.filter_by(

        gi_tag_id=gi_tag_id,

        is_gi_product=True

    ).all()

    return products