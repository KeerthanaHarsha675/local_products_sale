"""
=========================================================
HeritageHandcrafts - JWT Manager
=========================================================
"""

from flask_jwt_extended import JWTManager

# Create JWT Manager Object
jwt = JWTManager()


def initialize_jwt(app):
    """
    Initialize JWT for Flask App
    """
    jwt.init_app(app)